<?php
include 'db.php';

$image=$_POST['image'];
$latitude=$_POST['latitude'];
$longitude=$_POST['longitude'];

$image=str_replace('data:image/png;base64,','',$image);
$image=str_replace(' ','+',$image);

$imageName="uploads/logout_".time().".png";
file_put_contents($imageName,base64_decode($image));

$logout_time=date("H:i:s");

$result=$conn->query("SELECT * FROM attendance ORDER BY id DESC LIMIT 1");
$row=$result->fetch_assoc();

$login_time=$row['login_time'];

$start=new DateTime($login_time);
$end=new DateTime($logout_time);
$interval=$start->diff($end);

$hours=$interval->h;
$minutes=$interval->i;

$working_hours=$hours." Hours ".$minutes." Minutes";

$conn->query("UPDATE attendance SET
logout_photo='$imageName',
logout_latitude='$latitude',
logout_longitude='$longitude',
logout_time='$logout_time',
working_hours='$working_hours'
WHERE id=".$row['id']);

echo "Logout Saved";
?>