<!DOCTYPE html>
<html>
<head>
<title>Employee Logout</title>
</head>
<body>

<h2>Employee Logout (OUT)</h2>

<video id="video" width="320" height="250" autoplay></video><br><br>
<button onclick="captureLogout()">Mark OUT</button>
<canvas id="canvas" width="320" height="250" style="display:none;"></canvas>

<script>
let video=document.getElementById("video");

navigator.mediaDevices.getUserMedia({video:true})
.then(stream=>{ video.srcObject=stream; })
.catch(err=>{ alert("Allow camera access!"); });

function captureLogout(){

    let canvas=document.getElementById("canvas");
    let context=canvas.getContext("2d");
    context.drawImage(video,0,0,320,250);

    navigator.geolocation.getCurrentPosition(function(position){

        let lat=position.coords.latitude;
        let lon=position.coords.longitude;

        let now=new Date();
        let date=now.toLocaleDateString();
        let time=now.toLocaleTimeString();

        fetch("https://nominatim.openstreetmap.org/reverse?format=json&lat="+lat+"&lon="+lon)
        .then(res=>res.json())
        .then(data=>{

            let address=data.display_name;

            context.fillStyle="rgba(0,0,0,0.6)";
            context.fillRect(0,150,320,100);

            context.fillStyle="yellow";
            context.font="11px Arial";

            context.fillText("LOGOUT",10,165);
            context.fillText("Date: "+date,10,180);
            context.fillText("Time: "+time,10,195);
            context.fillText(address.substring(0,40),10,210);
            context.fillText(address.substring(40,80),10,225);

            let image=canvas.toDataURL("image/png");

            let xhr=new XMLHttpRequest();
            xhr.open("POST","save_logout.php",true);
            xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
            xhr.send("image="+image+"&latitude="+lat+"&longitude="+lon);

            alert("Logout Saved");
            window.location="manager_dashboard.php";
        });

    },function(){
        alert("Allow location access!");
    });
}
</script>

</body>
</html>