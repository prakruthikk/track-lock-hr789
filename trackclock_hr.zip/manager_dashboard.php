<?php
include 'db.php';
$result = $conn->query("SELECT * FROM attendance ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
<title>Manager Dashboard</title>
</head>
<body>

<h2>Attendance Photos</h2>

<?php while($row = $result->fetch_assoc()) { ?>

    <h3>Employee ID: <?php echo $row['user_id']; ?></h3>

    <p><b>Login Photo:</b></p>
    <img src="<?php echo $row['login_photo']; ?>" width="300"><br><br>

    <p><b>Logout Photo:</b></p>
    <img src="<?php echo $row['logout_photo']; ?>" width="300"><br><br>

    <hr>

<?php } ?>

</body>
</html>