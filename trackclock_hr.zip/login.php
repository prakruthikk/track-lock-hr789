<!DOCTYPE html>
<html>
<head>
<title>Employee Login</title>
</head>
<body>

<h2>Employee Login (IN)</h2>

<video id="video" width="320" height="250" autoplay></video><br><br>
<button onclick="captureLogin()">Mark IN</button>
<canvas id="canvas" width="320" height="250" style="display:none;"></canvas>

<script>
let video = document.getElementById("video");

navigator.mediaDevices.getUserMedia({video:true})
.then(stream => { video.srcObject = stream; })
.catch(err => { alert("Allow camera access!"); });

function captureLogin(){

    let canvas=document.getElementById("canvas");
    let context=canvas.getContext("2d");
    context.drawImage(video,0,0,320,250);

    navigator.geolocation.getCurrentPosition(function(position){

        let lat=position.coords.latitude;
        let lon=position.coords.longitude;

        let now=new Date();
        let date=now.toLocaleDateString();
        let time=now.toLocaleTimeString();

        fetch("https://nominatim.openstreetmap.org/reverse?format=json&lat="+lat+"&lon="+lon)
        .then(res=>res.json())
        .then(data=>{

            let address=data.display_name;

            context.fillStyle="rgba(0,0,0,0.6)";
            context.fillRect(0,160,320,90);

            context.fillStyle="white";
            context.font="11px Arial";

            context.fillText("LOGIN",10,175);
            context.fillText("Date: "+date,10,190);
            context.fillText("Time: "+time,10,205);
            context.fillText(address.substring(0,40),10,220);
            context.fillText(address.substring(40,80),10,235);

            let image=canvas.toDataURL("image/png");

            let xhr=new XMLHttpRequest();
            xhr.open("POST","save_login.php",true);
            xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
            xhr.send("image="+image+"&latitude="+lat+"&longitude="+lon);

            alert("Login Saved");
            window.location="logout.php";
        });

    },function(){
        alert("Allow location access!");
    });
}
</script>

</body>
</html>