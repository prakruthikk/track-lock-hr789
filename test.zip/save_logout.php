<?php
include 'db.php';

$image = $_POST['image'];
$latitude = $_POST['latitude'];
$longitude = $_POST['longitude'];

$image = str_replace('data:image/png;base64,', '', $image);
$image = str_replace(' ', '+', $image);

$imageName = "uploads/logout_" . time() . ".png";
file_put_contents($imageName, base64_decode($image));

$date = date("Y-m-d");
$logout_time = date("H:i:s");

$sql = "UPDATE attendance 
SET logout_photo='$imageName',
    logout_latitude='$latitude',
    logout_longitude='$longitude',
    logout_time='$logout_time'
WHERE user_id=1 AND date='$date'";

$conn->query($sql);

echo "Logout Saved";
?>