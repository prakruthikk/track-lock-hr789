<!DOCTYPE html>
<html>
<head>
    <title>Logout Attendance</title>
</head>
<body>

<h2>Logout - Capture Live Photo</h2>

<video id="video" width="300" height="250" autoplay></video>
<br><br>
<button onclick="captureLogout()">Logout & Mark OUT</button>

<canvas id="canvas" width="300" height="250" style="display:none;"></canvas>

<script>
navigator.mediaDevices.getUserMedia({ video: true })
.then(stream => {
    document.getElementById('video').srcObject = stream;
});

function captureLogout() {

    let canvas = document.getElementById('canvas');
    let video = document.getElementById('video');

    canvas.getContext('2d').drawImage(video, 0, 0, 300, 250);

    let imageData = canvas.toDataURL("image/png");

    navigator.geolocation.getCurrentPosition(function(position) {

        let latitude = position.coords.latitude;
        let longitude = position.coords.longitude;

        let xhr = new XMLHttpRequest();
        xhr.open("POST", "save_logout.php", true);
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

        xhr.send("image=" + imageData +
                 "&latitude=" + latitude +
                 "&longitude=" + longitude);

        alert("Logout Saved!");
        window.location = "login.php";

    }, function() {
        alert("Please allow location access!");
    });
}
</script>

</body>
</html>