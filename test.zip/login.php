<!DOCTYPE html>
<html>
<head>
    <title>Company Attendance - Login</title>
</head>
<body>

<h2>Employee Login - Mark Attendance</h2>

<video id="video" width="320" height="240" autoplay></video>
<br><br>

<p><strong>Current Time:</strong> <span id="time"></span></p>
<p><strong>Location:</strong> <span id="locationText">Waiting for location...</span></p>
<p><strong>Map Link:</strong> <span id="mapLink"></span></p>

<br>
<button onclick="captureLogin()">Login & Mark IN</button>

<canvas id="canvas" width="320" height="240" style="display:none;"></canvas>

<script>

// Show live time
setInterval(() => {
    let now = new Date();
    document.getElementById("time").innerHTML = now.toLocaleString();
}, 1000);

// Start camera
navigator.mediaDevices.getUserMedia({ video: true })
.then(stream => {
    document.getElementById('video').srcObject = stream;
})
.catch(() => {
    alert("Camera access denied!");
});

let currentLatitude = "";
let currentLongitude = "";

// Get location automatically when page loads
navigator.geolocation.getCurrentPosition(function(position) {

    currentLatitude = position.coords.latitude;
    currentLongitude = position.coords.longitude;

    document.getElementById("locationText").innerHTML =
        currentLatitude + " , " + currentLongitude;

    let mapURL = "https://www.google.com/maps?q=" +
                 currentLatitude + "," + currentLongitude;

    document.getElementById("mapLink").innerHTML =
        "<a href='" + mapURL + "' target='_blank'>View on Map</a>";

}, function() {
    alert("Please allow location access!");
});

function captureLogin() {

    let canvas = document.getElementById('canvas');
    let video = document.getElementById('video');
    let context = canvas.getContext('2d');

    context.drawImage(video, 0, 0, 320, 240);

    let imageData = canvas.toDataURL("image/png");

    let xhr = new XMLHttpRequest();
    xhr.open("POST", "save_login.php", true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            alert("Attendance Marked Successfully!");
            window.location = "logout.php";
        }
    };

    xhr.send(
        "image=" + encodeURIComponent(imageData) +
        "&latitude=" + currentLatitude +
        "&longitude=" + currentLongitude
    );
}

</script>

</body>
</html>