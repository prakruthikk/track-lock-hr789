<?php
include 'db.php';

$result = $conn->query("SELECT * FROM attendance ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manager Attendance Dashboard</title>
</head>
<body>

<h2>Attendance Report</h2>

<table border="1" cellpadding="10">
<tr>
    <th>ID</th>
    <th>User</th>
    <th>Login Photo</th>
    <th>Login Location</th>
    <th>Login Time</th>
    <th>Logout Photo</th>
    <th>Logout Location</th>
    <th>Logout Time</th>
    <th>Date</th>
</tr>

<?php while($row = $result->fetch_assoc()) { ?>
<tr>
    <td><?php echo $row['id']; ?></td>
    <td><?php echo $row['user_id']; ?></td>

    <td>
        <?php if($row['login_photo']) { ?>
            <img src="<?php echo $row['login_photo']; ?>" width="100">
        <?php } ?>
    </td>

    <td>
        <?php if($row['login_latitude']) { ?>
            <a href="https://www.google.com/maps?q=<?php echo $row['login_latitude']; ?>,<?php echo $row['login_longitude']; ?>" target="_blank">
                View Map
            </a>
        <?php } ?>
    </td>

    <td><?php echo $row['login_time']; ?></td>

    <td>
        <?php if($row['logout_photo']) { ?>
            <img src="<?php echo $row['logout_photo']; ?>" width="100">
        <?php } ?>
    </td>

    <td>
        <?php if($row['logout_latitude']) { ?>
            <a href="https://www.google.com/maps?q=<?php echo $row['logout_latitude']; ?>,<?php echo $row['logout_longitude']; ?>" target="_blank">
                View Map
            </a>
        <?php } ?>
    </td>

    <td><?php echo $row['logout_time']; ?></td>
    <td><?php echo $row['date']; ?></td>
</tr>
<?php } ?>

</table>

</body>
</html>