<?php
include 'db.php';

if(isset($_POST['image']) && isset($_POST['latitude']) && isset($_POST['longitude'])) {

    $image = $_POST['image'];
    $latitude = $_POST['latitude'];
    $longitude = $_POST['longitude'];

    // Remove base64 header
    $image = str_replace('data:image/png;base64,', '', $image);
    $image = str_replace(' ', '+', $image);

    $imageName = "uploads/login_" . time() . ".png";

    // Save image
    if(file_put_contents($imageName, base64_decode($image))) {

        $date = date("Y-m-d");
        $login_time = date("H:i:s");

        $sql = "INSERT INTO attendance 
        (user_id, login_photo, login_latitude, login_longitude, login_time, date)
        VALUES 
        (1, '$imageName', '$latitude', '$longitude', '$login_time', '$date')";

        if($conn->query($sql)) {
            echo "Login Saved Successfully";
        } else {
            echo "Database Error: " . $conn->error;
        }

    } else {
        echo "Image Save Failed";
    }

} else {
    echo "POST data missing";
}
?>